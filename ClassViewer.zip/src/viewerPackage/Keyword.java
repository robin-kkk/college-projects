package viewerPackage;

public class Keyword {
    public static final String CLASS = "class";
    public static final String[] TYPE = {"void","bool","int"};
    public static final String[] CONTROLSTATEMENT = {"if","else"};
    public static final String[] ACCESS = {"public","private"};
}
