<?php
header("content-type:text/html; charset=UTF-8");
setcookie("COOKIES", "", 0, "/");
setcookie("pid", "", 0, "/");
setcookie("lat", "", 0, "/");
setcookie("lat", "", 0, "/");
?>


<script>
    location.href="../../index.php";
</script>