<?php
$saying = array(
    "He who would travel happily must travel light.",
    "Travel is only glamorous in retrospect.",
    "Travel brings power and love back into your life.",
    "A man travels the world over in search of what he needs and returns home to find it.",
    "Travel is fatal to prejudice, bigotry, and narrow-mindeness.",
    "To travel is to take a journey into yourself.",
    "The world is a book and those who do not travel read only one page.",
    "One's destination is never a place, but a new way of seeing things."
);
?>