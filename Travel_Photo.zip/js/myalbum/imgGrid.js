;
(function (window) {
    'use strict'; // 전역변수(함수표현식 외부) 사용을 금지

    /* Source by https://modernizr.com/docs */
    var support = {
            transitions: Modernizr.csstransitions
        }, // 브라우저호환검사
        // transition end event name
        transEndEventNames = {
            'WebkitTransition': 'webkitTransitionEnd',
            'MozTransition': 'transitionend',
            'OTransition': 'oTransitionEnd',
            'msTransition': 'MSTransitionEnd',
            'transition': 'transitionend'
        },
        //브라우저가 해당 속성을 지원하는가
        transEndEventName = transEndEventNames[Modernizr.prefixed('transition')],
        onEndTransition = function (el, callback) {
            var onEndCallbackFn = function (ev) {
                if (support.transitions) {
                    if (ev.target != this) return;
                    // transition 지원할 경우, 이벤트가 끝나면 리스너를 제거
                    this.removeEventListener(transEndEventName, onEndCallbackFn);
                }
                // 콜백함수호출
                if (callback && typeof callback === 'function') {
                    callback.call(this);
                }
            };
            if (support.transitions) {
                // transition 지원할 경우, 이벤트 리스너 추가
                el.addEventListener(transEndEventName, onEndCallbackFn);
            } else {
                // 지원안할 경우 리스너설정없이 콜백함수만 호출됨. 
                onEndCallbackFn();
            }
        };
    /* some helper functions */

    function throttle(fn, delay) { /* control speed */
        var allowSample = true;

        return function (e) {
            if (allowSample) {
                allowSample = false;
                setTimeout(function () {
                    allowSample = true;
                }, delay);
                fn(e);
            }
        };
    }

    function nextSibling(el) { // p나 div 태그인 형제 태그를 찾아서 반환
        var nextSibling = el.nextSibling;
        while (nextSibling && nextSibling.nodeType != 1) {
            nextSibling = nextSibling.nextSibling
        }
        return nextSibling;
    }

    function extend(a, b) { // 객체 복사해주는 함수
        for (var key in b) {
            if (b.hasOwnProperty(key)) {
                a[key] = b[key];
            }
        }
        return a;
    }

    /* GridFx obj */
    function GridFx(el, options) {
        this.gridEl = el; // div class='grid'
        this.options = extend({}, this.options);
        extend(this.options, options);

        this.items = [].slice.call(this.gridEl.querySelectorAll('.grid__item'));
        this.previewEl = nextSibling(this.gridEl); // div class='preview'
        this.isExpanded = false;
        this.isAnimating = false;
        this.cmt_open = false;
        this.re_reply_open = false;
        this.closeCtrl = this.previewEl.querySelector('.preview--close');
        this.previewDescriptionEl = this.previewEl.querySelector('.description--preview');
        this._init();
    }

    /* options */
    GridFx.prototype.options = {
        pagemargin: 0,
        // x and y can have values from 0 to 1 (percentage). If negative then it means the alignment is left and/or top rather than right and/or bottom 음수면 top을 기준으로 25%, 양수면 bottom을 기준으로 25%
        // so, as an example, if we want our large image to be positioned vertically on 25% of the screen and centered horizontally the values would be x:1,y:-0.25
        imgPosition: {
            x: 1,
            y: 1
        },
        // 추가적인 함수 필요 시 재정의해서 사용하기 위함. (extend 함수를 통해 객체를 복사할 수 있으므로 재정의가능)
        onInit: function (instance) {
            return false;
        },
        onResize: function (instance) {
            return false;
        },
        onOpenItem: function (instance, item) {
            return false;
        },
        onCloseItem: function (instance, item) {
            return false;
        },
        onExpand: function () {
            return false;
        }
    }

    GridFx.prototype._init = function () {
        // callback
        this.options.onInit(this);
        var self = this;
        // init masonry after all images are loaded
        imagesLoaded(this.gridEl, function () {
            // initialize masonry
            new Masonry(self.gridEl, {
                itemSelector: '.grid__item',
                isFitWidth: true
            });
            // show grid after all images (thumbs) are loaded
            classie.add(self.gridEl, 'grid--loaded');
            // init/bind events
            self._initEvents();
            // create the large image and append it to the DOM
            self._setOriginal();
            // create the clone image and append it to the DOM
            self._setClone();
        });

        var cmt = $(".input-comment");
        var cmttoggle = $(".comment-toggle");
        var $wrapper = $(".description--preview").children(".wrapper");
        cmt.hide();
        TweenMax.set($(".input-comment"), {
            y: 85
        });
        cmttoggle.click(function () {
            if (self.cmt_open) {
                TweenMax.to(cmt, 1, {
                    y: 85
                });
                self.re_reply_open = false;
                cmt.find(".refer").val(0);
                $(this).html("+").fadeOut(5).fadeIn();
            } else {
                TweenMax.to(cmt, 1, {
                    y: 0
                });
                $(this).html("-").fadeOut(5).fadeIn();
            }
            self.cmt_open = !self.cmt_open;
            cmt.children("form").trigger("reset");
            cmt.find("textarea").attr("placeholder", "Comment : ");
        });
        cmt.children("form").submit(function(e) {
            e.preventDefault();
            var $wrapper = $(".description--preview").children(".wrapper"),
                pnum = $wrapper.data("pnum"),
                $originwrapper = $("#post"+pnum).find(".wrapper"),
                form = $(this),
                refer = $(".refer").val();

            $.ajax({
                url: "../../php/board/comment/write_comment.php",
                type: "POST",
                data: {
                    "pnum": $wrapper.data("pnum"),
                    "refer": refer,
                    "contents": form.children("textarea").val()
                },
                success: function (data) {
                    if ((data == "Wrong Access.") || (data == "Contents is empty.")) {
                        alert(data);
                        return;
                    }
                    var cmtTable = $wrapper.find(".comment>table"),
                        originalCmtTable = $originwrapper.find(".comment>table"),
                        target = null;
                    if (refer == 0) {
                        if ($wrapper.find(".reply1").length == 0) {
                            originalCmtTable.html(data);
                            target = cmtTable.html(data).children(".reply1").hide().fadeIn();
                        }
                        else {
                            originalCmtTable.append(data);
                            target = cmtTable.append(data).children(".reply1:last").hide().fadeIn();
                        }
                    } else {
                        if ($wrapper.find(".refer" + refer).length == 0) {
                            $originwrapper = $originwrapper.find("#cnum" + refer);
                            target = $wrapper.find("#cnum" + refer);
                        } else {
                            $originwrapper = $originwrapper.find(".refer" + refer + ":last");
                            target = $wrapper.find(".refer" + refer + ":last");
                        }
                        $originwrapper.after(data);
                        target.after(data).next().hide().fadeIn();
                    }
                    TweenMax.fromTo(target.next(), 0.8, {
                        color: "red"
                    }, {
                        color: "white"
                    });
                    if ($wrapper.height() >= $(window).height()) {
                        $wrapper.addClass("set_zero_to_top");
                        var pos;
                        if (refer == 0) {
                            pos = cmtTable.height() + cmtTable.offset().top;
                            $wrapper.parent().animate({
                                scrollTop: pos
                            }, 400);
                        } else {
                            pos = target.offset().top + target.height();
                            $wrapper.parent().animate({
                                scrollTop: pos
                            }, 400);
                        }
                    }
                    var count = parseInt($wrapper.find(".cmtcount").text()) + 1;
                    $wrapper.find(".cmtcount").html(count).fadeOut().fadeIn();
                    $originwrapper.find(".cmtcount").html(count);
                    cmttoggle.trigger("click");
                }
            })
        });
    };

    /* initialize/bind events */
    GridFx.prototype._initEvents = function () {
        var self = this,
            clickEvent = (document.ontouchstart !== null ? 'click' : 'touchstart');
        this.items.forEach(function (item) {
            var touchend = function (ev) {
                    ev.preventDefault();
                    self._openItem(ev, item);
                    item.removeEventListener('touchend', touchend);
                },
                touchmove = function (ev) {
                    item.removeEventListener('touchend', touchend);
                },
                manageTouch = function () {
                    item.addEventListener('touchend', touchend);
                    item.addEventListener('touchmove', touchmove);
                };

            item.addEventListener(clickEvent, function (ev) {
                if (clickEvent === 'click') {
                    ev.preventDefault();
                    self._openItem(ev, item);
                } else {
                    manageTouch();
                }
            });
        });
        // close expanded image
        this.closeCtrl.addEventListener('click', function () {
            self._closeItem();
        });

        window.addEventListener('resize', throttle(function (ev) {
            // callback
            self.options.onResize(self);
        }, 10));
    }

    /**
     * open a grid item
     */
    GridFx.prototype._openItem = function (ev, item) {
        if (this.isAnimating || this.isExpanded) return;
        this.isAnimating = true;
        this.isExpanded = true;

        // item's image
        var gridImg = item.querySelector('img'),
            gridImgOffset = gridImg.getBoundingClientRect();

        // index of current item
        this.current = this.items.indexOf(item);

        // set the src of the original image element (large image)
        this._setOriginal(item.querySelector('a').getAttribute('href'));

        // callback
        this.options.onOpenItem(this, item);

        // set the clone image
        this._setClone(gridImg.src, {
            width: gridImg.offsetWidth,
            height: gridImg.offsetHeight,
            left: gridImgOffset.left,
            top: gridImgOffset.top,
        });

        // hide original grid item
        classie.add(item, 'grid__item--current');

        // calculate the transform value for the clone to animate to the full image view
        var win = this._getWinSize(),
            originalSizeArr = item.getAttribute('data-size').split('x'),
            originalSize = {
                width: originalSizeArr[0],
                height: originalSizeArr[1]
            },
            dx = ((this.options.imgPosition.x > 0 ? 1 - Math.abs(this.options.imgPosition.x) : Math.abs(this.options.imgPosition.x)) * win.width + this.options.imgPosition.x * win.width / 2) - gridImgOffset.left - 0.5 * gridImg.offsetWidth,
            dy = ((this.options.imgPosition.y > 0 ? 1 - Math.abs(this.options.imgPosition.y) : Math.abs(this.options.imgPosition.y)) * win.height + this.options.imgPosition.y * win.height / 2) - gridImgOffset.top - 0.5 * gridImg.offsetHeight,
            z = Math.min(Math.min(win.width * Math.abs(this.options.imgPosition.x) - this.options.pagemargin, originalSize.width - this.options.pagemargin) / gridImg.offsetWidth, Math.min(win.height * Math.abs(this.options.imgPosition.y) - this.options.pagemargin, originalSize.height - this.options.pagemargin) / gridImg.offsetHeight);
        // apply transform to the clone
        this.cloneImg.style.WebkitTransform = 'translate3d(' + dx + 'px, ' + dy + 'px, 0) scale3d(' + z + ', ' + z + ', 1)';
        this.cloneImg.style.transform = 'translate3d(' + dx + 'px, ' + dy + 'px, 0) scale3d(' + z + ', ' + z + ', 1)';
        
        // add the description if any
        var descriptionEl = item.querySelector('.description--grid');
        if (descriptionEl) {
            var self = this;
            this.previewDescriptionEl.innerHTML = descriptionEl.innerHTML;
            var wrapper = this.previewDescriptionEl.querySelector(".wrapper");
            if (wrapper.getBoundingClientRect().height >= window.innerHeight)
                classie.add(wrapper, 'set_zero_to_top');
            else
                classie.remove(wrapper, 'set_zero_to_top');

            var $wrapper = $(".description--preview").children(".wrapper"),
                $originwrapper = $("#post"+$wrapper.data("pnum")),
                cmt = $(".input-comment"),
                cmttoggle = cmt.children(".comment-toggle");
            
            cmttoggle.html("+");
            cmt.show();
            $("#pnum").val(gridImg.alt);
            TweenMax.set(cmt, {
                y: 85
            });

            $wrapper.find(".post-delete").click(function() {
                var res = confirm('Would you like to delete this post?');
                if (res) {
                    var pnum = $(this).data("pnum"),
                        writer = $(this).data("writer");
                    $.ajax({
                        url: "php/board/delete_post.php",
                        type: "POST",
                        data: {
                            "pnum": pnum,
                            "writer": writer
                        },
                        success: function () {
                            $(".preview--close").trigger("click");
                            $("#post" + pnum).remove();
                        }
                    });
                }
            });
            
            $wrapper.find(".like").click(function() {
                var btn = $(this),
                    liked = !btn.hasClass("like_before"),
                    pnum = btn.attr("value");
                $.ajax({
                    url: "../../php/board/like.php",
                    type: "POST",
                    data: {
                        "pnum": pnum,
                        "liked": liked
                    },
                    success: function () {
                        var path = "img/basic/",
                            label = btn.next();
                        btn.toggleClass("like_before").toggleClass("like_after");
                        $originwrapper.find(".like")
                            .toggleClass("like_before")
                            .toggleClass("like_after");
                        var liker = parseInt(label.attr("value"));
                        if (liked) {
                            liker--;
                            path += "like2.svg";
                        } else {
                            liker++;
                            path += "like_after.svg";
                        }
                        label.attr("value", liker).html(liker);
                        $originwrapper.find(".like").next().attr("value", liker).html(liker);
                        TweenMax.fromTo([label, btn], 0.2, {
                            opacity: 0,
                            onComplete: function () {
                                btn.children("img").attr("src", path);
                                $originwrapper.find(".like").children("img").attr("src", path);
                            }
                        }, {
                            opacity: 1
                        });
                    }
                }); 
            });
            
            $wrapper.on("click", ".re-reply", function() {
                var btn = $(this);
                cmttoggle.html("-").fadeOut(5).fadeIn();
                cmt.children("form").trigger("reset");
                cmt.find("textarea").attr("placeholder", "Reply to "+btn.attr("value"));
                var end_y =  -($(window).height()-btn.offset().top-130);
                if (end_y > 85) end_y = 85;
                TweenMax.to(cmt, 1, {
                    y: end_y
                });
                self.cmt_open = true;
                self.re_reply_open = true;
                cmt.find(".refer").val(btn.attr("name"));
            });
            
            $wrapper.on("click", ".reply-delete", function() {
                var btn = $(this);
                btn.click(function(e) {
                    e.preventDefault();
                    var res = confirm('Would you like to delete this comment?');
                    if (res) {
                        var pnum = $wrapper.data("pnum"),
                            cnum = btn.data("cnum"),
                            c_writer = btn.data("cwriter");
                        $.ajax({
                            url: "../../php/board/comment/delete_comment.php",
                            type: "POST",
                            data: {
                                "pnum": pnum,
                                "cnum": cnum,
                                "c_writer": c_writer
                            },
                            success: function(data) {
                                if (data.search("Wrong") != -1) {
                                    alert(data);
                                    return;
                                }
                                var count = parseInt($wrapper.find(".cmtcount").text())-1;
                                var target = $(".delete"+cnum).closest("tr");
                                if (target.hasClass("reply1") && ($(".refer"+cnum).length != 0)) {
                                    target = $(".refer"+cnum+","+"#cnum"+cnum);
                                    count -= $wrapper.find(".refer"+cnum).length;
                                }
                                
                                target.fadeOut("slow", function() {
                                    $(this).remove();
                                });
                                
                                
                                if ($wrapper.height() < $(window).height()) {
                                    $wrapper.removeClass("set_zero_to_top");
                                }
                                $wrapper.find(".cmtcount").text(count).fadeOut().fadeIn();
                                $originwrapper.find(".cmtcount").text(count).fadeOut().fadeIn();
                            }
                        })
                    }
                });
            });
        }

        setTimeout(function () {
            // controls the elements inside the expanded view
            classie.add(self.previewEl, 'preview--open');
            // callback
            self.options.onExpand();
        }, 0);

        // after the clone animates..
        onEndTransition(this.cloneImg, function () {
            // when the original/large image is loaded..
            imagesLoaded(self.originalImg, function () {
                // close button just gets shown after the large image gets loaded
                classie.add(self.previewEl, 'preview--image-loaded');
                // animate the opacity to 1
                self.originalImg.style.opacity = 1;
                // and once that's done..
                onEndTransition(self.originalImg, function () {
                    // reset cloneImg
                    self.cloneImg.style.opacity = 0;
                    self.cloneImg.style.WebkitTransform = 'translate3d(0,0,0) scale3d(1,1,1)';
                    self.cloneImg.style.transform = 'translate3d(0,0,0) scale3d(1,1,1)';

                    self.isAnimating = false;
                });

            });
        });
    };

    /**
     * create/set the original/large image element
     */
    GridFx.prototype._setOriginal = function (src) {
        if (!src) {
            this.originalImg = document.createElement('img');
            this.originalImg.className = 'original';
            this.originalImg.style.opacity = 0;
            this.originalImg.style.maxWidth = 'calc(' + parseInt(Math.abs(this.options.imgPosition.x) * 100) + 'vw - ' + this.options.pagemargin + 'px)';
            this.originalImg.style.maxHeight = 'calc(' + parseInt(Math.abs(this.options.imgPosition.y) * 100) + 'vh - ' + this.options.pagemargin + 'px)';
            // need it because of firefox
            this.originalImg.style.WebkitTransform = 'translate3d(0,0,0) scale3d(1,1,1)';
            this.originalImg.style.transform = 'translate3d(0,0,0) scale3d(1,1,1)';
            src = '';
            this.previewEl.appendChild(this.originalImg);
        }

        this.originalImg.setAttribute('src', src);
    };

    /**
     * create/set the clone image element
     */
    GridFx.prototype._setClone = function (src, settings) {
        if (!src) {
            this.cloneImg = document.createElement('img');
            this.cloneImg.className = 'clone';
            src = '';
            this.cloneImg.style.opacity = 0;
            this.previewEl.appendChild(this.cloneImg);
        } else {
            this.cloneImg.style.opacity = 1;
            // set top/left/width/height of grid item's image to the clone
            this.cloneImg.style.width = settings.width + 'px';
            this.cloneImg.style.height = settings.height + 'px';
            this.cloneImg.style.top = settings.top + 'px';
            this.cloneImg.style.left = settings.left + 'px';
        }

        this.cloneImg.setAttribute('src', src);
    };

    /**
     * closes the original/large image view
     */
    GridFx.prototype._closeItem = function () {
        $(".input-comment").hide();
        this.cmt_open = false;
        this.re_reply_open = false;
        if (!this.isExpanded || this.isAnimating) return;
        this.isExpanded = false;
        this.isAnimating = true;

        // the grid item's image and its offset
        var gridItem = this.items[this.current],
            gridImg = gridItem.querySelector('img'),
            gridImgOffset = gridImg.getBoundingClientRect(),
            self = this;

        classie.remove(this.previewEl, 'preview--open');
        classie.remove(this.previewEl, 'preview--image-loaded');

        // callback
        this.options.onCloseItem(this, gridItem);

        // large image will animate back to the position of its grid's item
        classie.add(this.originalImg, 'animate');

        // set the transform to the original/large image
        var win = this._getWinSize(),
            dx = gridImgOffset.left + gridImg.offsetWidth / 2 - ((this.options.imgPosition.x > 0 ? 1 - Math.abs(this.options.imgPosition.x) : Math.abs(this.options.imgPosition.x)) * win.width + this.options.imgPosition.x * win.width / 2),
            dy = gridImgOffset.top + gridImg.offsetHeight / 2 - ((this.options.imgPosition.y > 0 ? 1 - Math.abs(this.options.imgPosition.y) : Math.abs(this.options.imgPosition.y)) * win.height + this.options.imgPosition.y * win.height / 2),
            z = gridImg.offsetWidth / this.originalImg.offsetWidth;

        this.originalImg.style.WebkitTransform = 'translate3d(' + dx + 'px, ' + dy + 'px, 0) scale3d(' + z + ', ' + z + ', 1)';
        this.originalImg.style.transform = 'translate3d(' + dx + 'px, ' + dy + 'px, 0) scale3d(' + z + ', ' + z + ', 1)';

        // once that's done..
        onEndTransition(this.originalImg, function () {
            // clear description
            self.previewDescriptionEl.innerHTML = '';

            // show original grid item
            classie.remove(gridItem, 'grid__item--current');

            // fade out the original image
            setTimeout(function () {
                self.originalImg.style.opacity = 0;
            }, 60);

            // and after that
            onEndTransition(self.originalImg, function () {
                // reset original/large image
                classie.remove(self.originalImg, 'animate');
                self.originalImg.style.WebkitTransform = 'translate3d(0,0,0) scale3d(1,1,1)';
                self.originalImg.style.transform = 'translate3d(0,0,0) scale3d(1,1,1)';

                self.isAnimating = false;
            });
        });
    };

    /**
     * gets the window sizes
     */
    GridFx.prototype._getWinSize = function () {
        return {
            width: document.documentElement.clientWidth,
            height: window.innerHeight
        };
    };

    window.GridFx = GridFx;

})(window);
